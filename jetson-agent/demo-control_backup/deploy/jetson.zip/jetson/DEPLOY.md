# Jetson 部署说明

## 1. 拷贝项目到小车

```bash
sudo mkdir -p /opt/demo-control
sudo cp -r /path/to/demo-control/* /opt/demo-control/
sudo chown -R wheeltec:wheeltec /opt/demo-control
```

## 2. 手工启动 3000 服务

```bash
cd /opt/demo-control
chmod +x deploy/jetson/start_demo_control.sh
APP_ROOT=/opt/demo-control APP_HOST=0.0.0.0 APP_PORT=3000 ./deploy/jetson/start_demo_control.sh
```

## 3. 验证服务

```bash
curl http://127.0.0.1:3000/api/status
ss -lntp | grep 3000
```

## 4. 配置为 systemd 常驻服务

```bash
sudo cp /opt/demo-control/deploy/jetson/demo-control.service /etc/systemd/system/demo-control.service
sudo systemctl daemon-reload
sudo systemctl enable demo-control
sudo systemctl start demo-control
sudo systemctl status demo-control
```

## 5. 如果还需要同时启动 8001 robot_agent

```bash
cd /opt/demo-control
python3 -m venv .venv
source .venv/bin/activate
pip install -r jetson-agent/requirements.txt
START_ROBOT_AGENT=true APP_ROOT=/opt/demo-control APP_HOST=0.0.0.0 APP_PORT=3000 ./deploy/jetson/start_demo_control.sh
```
