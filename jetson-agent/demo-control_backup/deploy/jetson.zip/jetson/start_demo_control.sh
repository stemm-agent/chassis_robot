#!/usr/bin/env bash
set -euo pipefail

APP_ROOT=${APP_ROOT:-/opt/demo-control}
APP_HOST=${APP_HOST:-0.0.0.0}
APP_PORT=${APP_PORT:-3000}
START_ROBOT_AGENT=${START_ROBOT_AGENT:-false}
ROBOT_AGENT_PORT=${ROBOT_AGENT_PORT:-8001}
ROS_SETUP=${ROS_SETUP:-/opt/ros/humble/setup.bash}
VENV_PATH=${VENV_PATH:-$APP_ROOT/.venv}

cd "$APP_ROOT"

if ! command -v node >/dev/null 2>&1; then
  echo "[ERROR] node not found. Please install Node.js first."
  exit 1
fi

if ! command -v npm >/dev/null 2>&1; then
  echo "[ERROR] npm not found. Please install npm first."
  exit 1
fi

if [ -f ".env" ]; then
  set -a
  . ./.env
  set +a
fi

export HOST="$APP_HOST"
export PORT="$APP_PORT"

if [ ! -d "node_modules" ]; then
  echo "[INFO] Installing Node.js dependencies..."
  npm install
fi

if [ "$START_ROBOT_AGENT" = "true" ]; then
  if ! command -v python3 >/dev/null 2>&1; then
    echo "[ERROR] python3 not found, cannot start robot agent."
    exit 1
  fi

  if [ -f "$ROS_SETUP" ]; then
    # Load ROS 2 environment for the robot-side HTTP agent.
    . "$ROS_SETUP"
  fi

  if [ -f "$VENV_PATH/bin/activate" ]; then
    . "$VENV_PATH/bin/activate"
  fi

  if [ ! -f "$APP_ROOT/jetson-agent/robot_agent.py" ]; then
    echo "[ERROR] robot_agent.py not found under $APP_ROOT/jetson-agent"
    exit 1
  fi

  if ! pgrep -f "robot_agent.py" >/dev/null 2>&1; then
    echo "[INFO] Starting robot agent on port $ROBOT_AGENT_PORT..."
    export JETSON_AGENT_URL="http://127.0.0.1:$ROBOT_AGENT_PORT"
    nohup python3 "$APP_ROOT/jetson-agent/robot_agent.py" > "$APP_ROOT/robot_agent.log" 2>&1 &
  fi
fi

echo "[INFO] Starting demo-control on ${APP_HOST}:${APP_PORT}"
exec npm start
